from src.models.user import db
from datetime import datetime
import json

class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kobo_id = db.Column(db.String(100), unique=True, nullable=False)
    form_id = db.Column(db.String(100), nullable=False)
    submission_time = db.Column(db.DateTime, nullable=False)
    data = db.Column(db.Text, nullable=False)  # JSON string of submission data
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    images = db.Column(db.Text, nullable=True)  # JSON array of image URLs
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Submission {self.kobo_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'kobo_id': self.kobo_id,
            'form_id': self.form_id,
            'submission_time': self.submission_time.isoformat() if self.submission_time else None,
            'data': json.loads(self.data) if self.data else {},
            'latitude': self.latitude,
            'longitude': self.longitude,
            'images': json.loads(self.images) if self.images else [],
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

    @staticmethod
    def from_kobo_data(kobo_submission):
        """Create a Submission instance from KoBo API data"""
        # Extract geolocation if available
        latitude = None
        longitude = None
        if '_geolocation' in kobo_submission and kobo_submission['_geolocation']:
            geolocation = kobo_submission['_geolocation']
            try:
                if isinstance(geolocation, list) and len(geolocation) >= 2:
                    if geolocation[0] is not None and geolocation[1] is not None:
                        latitude = float(geolocation[0])
                        longitude = float(geolocation[1])
                elif isinstance(geolocation, dict):
                    if 'latitude' in geolocation and 'longitude' in geolocation:
                        if geolocation['latitude'] is not None and geolocation['longitude'] is not None:
                            latitude = float(geolocation['latitude'])
                            longitude = float(geolocation['longitude'])
            except (ValueError, TypeError, IndexError):
                # If parsing fails, leave as None
                pass
        
        # Extract images from attachments
        images = []
        if '_attachments' in kobo_submission and kobo_submission['_attachments']:
            for attachment in kobo_submission['_attachments']:
                if attachment.get('mimetype', '').startswith('image/'):
                    images.append(attachment.get('download_url', ''))
        
        # Parse submission time
        submission_time = None
        if '_submission_time' in kobo_submission and kobo_submission['_submission_time']:
            try:
                submission_time = datetime.fromisoformat(kobo_submission['_submission_time'].replace('Z', '+00:00'))
            except:
                submission_time = datetime.utcnow()
        
        return Submission(
            kobo_id=str(kobo_submission.get('_id', '')),
            form_id=str(kobo_submission.get('_xform_id_string', '')),
            submission_time=submission_time or datetime.utcnow(),
            data=json.dumps(kobo_submission),
            latitude=latitude,
            longitude=longitude,
            images=json.dumps(images)
        )

