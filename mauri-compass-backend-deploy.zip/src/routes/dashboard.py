from flask import Blueprint, jsonify, request, current_app
from src.models.submission import Submission, db
from src.services.kobo_api import KoBoAPIService
import os
from werkzeug.utils import secure_filename
import json
from datetime import datetime

dashboard_bp = Blueprint('dashboard', __name__)

# KoBo API credentials and project configuration
KOBO_USERNAME = "ianruru"
KOBO_PASSWORD = "47WairereRoad"
KOBO_API_TOKEN = "374e4249725a4a64be9d90af7e1646559537c8c7"
PROJECT_NAME = "Mauri Compass Kura Fieldwork"
ASSET_UID = "a29yaZ8cTTpZ2Pc6dYjDgT"  # From shareable link

# Initialize KoBo API service
kobo_service = KoBoAPIService(KOBO_USERNAME, KOBO_PASSWORD, KOBO_API_TOKEN)

@dashboard_bp.route('/test-connection', methods=['GET'])
def test_kobo_connection():
    """Test connection to KoBo API"""
    try:
        is_connected = kobo_service.test_connection()
        if is_connected:
            # Get project info using specific asset UID
            submission_count = kobo_service.get_submission_count(ASSET_UID)
            project_info = {
                'asset_uid': ASSET_UID,
                'project_name': PROJECT_NAME,
                'submission_count': submission_count,
                'connected': True
            }
            return jsonify({
                'status': 'success',
                'connected': True,
                'project_info': project_info
            })
        else:
            return jsonify({
                'status': 'error',
                'connected': False,
                'message': 'Failed to connect to KoBo API'
            }), 500
    except Exception as e:
        return jsonify({
            'status': 'error',
            'connected': False,
            'message': str(e)
        }), 500

@dashboard_bp.route('/refresh-data', methods=['POST'])
def refresh_data_from_kobo():
    """Refresh data from KoBo API and store in local database"""
    try:
        # Get data from KoBo API using specific asset UID
        submissions_data = kobo_service.get_asset_data(ASSET_UID)
        
        if not submissions_data:
            return jsonify({
                'status': 'warning',
                'message': 'No data found in KoBo project',
                'count': 0
            })
        
        # Process and store submissions
        new_count = 0
        updated_count = 0
        
        for kobo_submission in submissions_data:
            kobo_id = str(kobo_submission.get('_id', ''))
            
            # Check if submission already exists
            existing = Submission.query.filter_by(kobo_id=kobo_id).first()
            
            if existing:
                # Update existing submission
                existing.data = json.dumps(kobo_submission)
                existing.updated_at = datetime.utcnow()
                
                # Update geolocation if available
                if '_geolocation' in kobo_submission:
                    geolocation = kobo_submission['_geolocation']
                    if isinstance(geolocation, list) and len(geolocation) >= 2:
                        existing.latitude = float(geolocation[0])
                        existing.longitude = float(geolocation[1])
                
                # Update images
                images = []
                if '_attachments' in kobo_submission:
                    for attachment in kobo_submission['_attachments']:
                        if attachment.get('mimetype', '').startswith('image/'):
                            images.append(attachment.get('download_url', ''))
                existing.images = json.dumps(images)
                
                updated_count += 1
            else:
                # Create new submission
                submission = Submission.from_kobo_data(kobo_submission)
                db.session.add(submission)
                new_count += 1
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': f'Data refreshed successfully',
            'new_submissions': new_count,
            'updated_submissions': updated_count,
            'total_processed': len(submissions_data)
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f'Error refreshing data: {str(e)}'
        }), 500

@dashboard_bp.route('/submissions', methods=['GET'])
def get_submissions():
    """Get all submissions from local database"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        submissions = Submission.query.order_by(Submission.submission_time.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'status': 'success',
            'submissions': [submission.to_dict() for submission in submissions.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': submissions.total,
                'pages': submissions.pages,
                'has_next': submissions.has_next,
                'has_prev': submissions.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@dashboard_bp.route('/submissions/<int:submission_id>', methods=['GET'])
def get_submission_detail(submission_id):
    """Get detailed information about a specific submission"""
    try:
        submission = Submission.query.get_or_404(submission_id)
        return jsonify({
            'status': 'success',
            'submission': submission.to_dict()
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@dashboard_bp.route('/map-data', methods=['GET'])
def get_map_data():
    """Get geolocation data for map display"""
    try:
        submissions = Submission.query.filter(
            Submission.latitude.isnot(None),
            Submission.longitude.isnot(None)
        ).all()
        
        map_data = []
        for submission in submissions:
            # Parse submission data to get relevant fields for popup
            data = json.loads(submission.data) if submission.data else {}
            
            map_data.append({
                'id': submission.id,
                'kobo_id': submission.kobo_id,
                'latitude': submission.latitude,
                'longitude': submission.longitude,
                'submission_time': submission.submission_time.isoformat() if submission.submission_time else None,
                'images': json.loads(submission.images) if submission.images else [],
                'preview_data': {
                    'form_id': submission.form_id,
                    # Add other relevant fields from the data for popup display
                    'title': data.get('title', 'Submission'),
                    'description': data.get('description', ''),
                }
            })
        
        return jsonify({
            'status': 'success',
            'map_data': map_data,
            'count': len(map_data)
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@dashboard_bp.route('/statistics', methods=['GET'])
def get_statistics():
    """Get dashboard statistics"""
    try:
        total_submissions = Submission.query.count()
        submissions_with_location = Submission.query.filter(
            Submission.latitude.isnot(None),
            Submission.longitude.isnot(None)
        ).count()
        submissions_with_images = Submission.query.filter(
            Submission.images.isnot(None),
            Submission.images != '[]'
        ).count()
        
        # Get recent submissions (last 7 days)
        from datetime import datetime, timedelta
        week_ago = datetime.utcnow() - timedelta(days=7)
        recent_submissions = Submission.query.filter(
            Submission.created_at >= week_ago
        ).count()
        
        return jsonify({
            'status': 'success',
            'statistics': {
                'total_submissions': total_submissions,
                'submissions_with_location': submissions_with_location,
                'submissions_with_images': submissions_with_images,
                'recent_submissions': recent_submissions,
                'location_percentage': round((submissions_with_location / total_submissions * 100) if total_submissions > 0 else 0, 1),
                'images_percentage': round((submissions_with_images / total_submissions * 100) if total_submissions > 0 else 0, 1)
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@dashboard_bp.route('/upload', methods=['POST'])
def upload_file():
    """Handle file uploads"""
    try:
        if 'file' not in request.files:
            return jsonify({
                'status': 'error',
                'message': 'No file provided'
            }), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({
                'status': 'error',
                'message': 'No file selected'
            }), 400
        
        if file:
            filename = secure_filename(file.filename)
            upload_folder = os.path.join(current_app.static_folder, 'uploads')
            os.makedirs(upload_folder, exist_ok=True)
            
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
            
            return jsonify({
                'status': 'success',
                'message': 'File uploaded successfully',
                'filename': filename,
                'url': f'/static/uploads/{filename}'
            })
            
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@dashboard_bp.route('/images', methods=['GET'])
def get_all_images():
    """Get all images from submissions"""
    try:
        submissions = Submission.query.filter(
            Submission.images.isnot(None),
            Submission.images != '[]'
        ).all()
        
        all_images = []
        for submission in submissions:
            images = json.loads(submission.images) if submission.images else []
            for image_url in images:
                all_images.append({
                    'submission_id': submission.id,
                    'kobo_id': submission.kobo_id,
                    'image_url': image_url,
                    'submission_time': submission.submission_time.isoformat() if submission.submission_time else None,
                    'latitude': submission.latitude,
                    'longitude': submission.longitude
                })
        
        return jsonify({
            'status': 'success',
            'images': all_images,
            'count': len(all_images)
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

