import requests
import json
from typing import List, Dict, Optional
from datetime import datetime

class KoBoAPIService:
    def __init__(self, username: str, password: str, api_token: str = None):
        self.username = username
        self.password = password
        self.api_token = api_token
        self.base_url = "https://kf.kobotoolbox.org"
        self.kc_base_url = "https://kc.kobotoolbox.org"
        
        # Set up authentication
        if api_token:
            self.headers = {
                'Authorization': f'Token {api_token}',
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
            self.auth = None
        else:
            self.headers = {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
            self.auth = (username, password)
    
    def get_assets(self) -> List[Dict]:
        """Get list of all assets (forms/projects)"""
        url = f"{self.base_url}/api/v2/assets/"
        try:
            response = requests.get(url, headers=self.headers, auth=self.auth)
            response.raise_for_status()
            data = response.json()
            return data.get('results', [])
        except requests.exceptions.RequestException as e:
            print(f"Error fetching assets: {e}")
            return []
    
    def find_asset_by_name(self, project_name: str) -> Optional[Dict]:
        """Find asset by project name"""
        assets = self.get_assets()
        for asset in assets:
            if asset.get('name', '').lower() == project_name.lower():
                return asset
        return None
    
    def get_asset_data(self, asset_uid: str) -> List[Dict]:
        """Get submission data for a specific asset"""
        url = f"{self.base_url}/api/v2/assets/{asset_uid}/data/"
        try:
            response = requests.get(url, headers=self.headers, auth=self.auth)
            response.raise_for_status()
            data = response.json()
            return data.get('results', [])
        except requests.exceptions.RequestException as e:
            print(f"Error fetching asset data: {e}")
            return []
    
    def get_project_data(self, project_name: str) -> List[Dict]:
        """Get all submission data for a project by name"""
        asset = self.find_asset_by_name(project_name)
        if not asset:
            print(f"Project '{project_name}' not found")
            return []
        
        asset_uid = asset.get('uid')
        if not asset_uid:
            print(f"No UID found for project '{project_name}'")
            return []
        
        return self.get_asset_data(asset_uid)
    
    def get_submission_count(self, asset_uid: str) -> int:
        """Get the number of submissions for an asset"""
        url = f"{self.base_url}/api/v2/assets/{asset_uid}/"
        try:
            response = requests.get(url, headers=self.headers, auth=self.auth)
            response.raise_for_status()
            data = response.json()
            return data.get('deployment__submission_count', 0)
        except requests.exceptions.RequestException as e:
            print(f"Error fetching submission count: {e}")
            return 0
    
    def submit_data(self, asset_uid: str, submission_data: Dict) -> bool:
        """Submit new data to a KoBo form"""
        url = f"{self.kc_base_url}/api/v1/submissions"
        
        # Prepare the submission data
        data = {
            'id': asset_uid,
            'submission': json.dumps(submission_data)
        }
        
        try:
            response = requests.post(url, data=data, auth=self.auth)
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            print(f"Error submitting data: {e}")
            return False
    
    def upload_media(self, file_path: str, asset_uid: str) -> Optional[str]:
        """Upload media file to KoBo"""
        url = f"{self.kc_base_url}/api/v1/files"
        
        try:
            with open(file_path, 'rb') as f:
                files = {'file': f}
                data = {'xform': asset_uid}
                response = requests.post(url, files=files, data=data, auth=self.auth)
                response.raise_for_status()
                result = response.json()
                return result.get('url')
        except Exception as e:
            print(f"Error uploading media: {e}")
            return None
    
    def test_connection(self) -> bool:
        """Test the API connection"""
        try:
            assets = self.get_assets()
            return len(assets) >= 0  # Even empty list means connection works
        except:
            return False
    
    def get_project_info(self, project_name: str) -> Optional[Dict]:
        """Get detailed information about a project"""
        asset = self.find_asset_by_name(project_name)
        if not asset:
            return None
        
        asset_uid = asset.get('uid')
        submission_count = self.get_submission_count(asset_uid)
        
        return {
            'uid': asset_uid,
            'name': asset.get('name'),
            'asset_type': asset.get('asset_type'),
            'date_created': asset.get('date_created'),
            'date_modified': asset.get('date_modified'),
            'submission_count': submission_count,
            'has_deployment': asset.get('has_deployment', False),
            'deployment_active': asset.get('deployment__active', False)
        }

